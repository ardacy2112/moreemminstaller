-- Steamtools auto-generated!

addappid(7, 1)
addappid(2768190, 1)
addappid(2855640, 1)
addappid(2855630, 1)
addappid(2855620, 1)
addappid(2528460, 1)
addappid(2855610, 1)
addappid(2768170, 1)
addappid(2544390, 1)
addappid(2584660, 1)
addappid(2768160, 1)
addappid(3180050, 1)
